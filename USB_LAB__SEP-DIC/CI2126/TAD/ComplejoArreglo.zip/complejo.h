/*
 * ARCHIVO: Complejo.h
 * DESCRIPCION: Contiene los prototipos, pre y post condiciones de las primitivas del tad TComplejo
 * AUTOR: Prof. Víctor Theoktisto
 * FECHA: 30/09/2010
 */

typedef float TComplejo[2];

void construirComplejo (TComplejo r, float n, float d);
/* PRE: y != 0
   POST: R_Crear devuelve un TComplejo con parte real x y parte imaginaria y */

void destruirComplejo (TComplejo r);
/* PRE: el TComplejo R ha sido creado
   POST: Libera el espacio ocupado por el TComplejo */

void clonarComplejo (TComplejo r, TComplejo p);
/* PRE: p.pimag != 0
   POST: R_Crear devuelve un TComplejo con parte real x y parte imaginaria y */

void sumarComplejo (TComplejo r, TComplejo x, TComplejo y);
/* PRE: los TComplejo x, y han sido creados
   POST: Devuelve la suma */

void conjugadoComplejo (TComplejo r, TComplejo p);
/* PRE: p.preal != 0
   POST: R_Crear devuelve un TComplejo con parte real x y parte imaginaria y */

float moduloComplejo (TComplejo r);
/* PRE: p != 0
   POST: R_Crear devuelve un TComplejo con parte real x y parte imaginaria y */

float radioComplejo (TComplejo r);

float anguloComplejo (TComplejo r);

void multiplicarComplejo (TComplejo r, TComplejo x, TComplejo y);
/* PRE: los TComplejo x, y han sido creados
   POST: Devuelve el producto */

float obtenerReal (TComplejo r);
/* PRE: el TComplejo R ha sido creado
   POST: Devuelve el parte real del TComplejo  */

float obtenerImag (TComplejo r);
/* PRE: el TComplejo R ha sido creado
   POST: Devuelve el parte imaginaria del TComplejo */

void fijarPreal (TComplejo r, float x);
/* PRE: el TComplejo R ha sido creado
   POST: Devuelve el TComplejo modificado con n como su parte real */

void fijarPimag (TComplejo r, float y);
/* PRE: el TComplejo R ha sido creado y d != 0
   POST: Devuelve el TComplejo modificado con d como su parte imaginaria  */

char * imprimirComplejo(TComplejo r);
/* PRE: el TComplejo R ha sido creado
   POST: Devuelve el string del Complejo  */


