#include <stdio.h>
#include <stdlib.h>
#include "../Triplets/triplets.h"
#include "complejo.h"

int main()
{
	TComplejo A, B, C, D, E, F;

	construirComplejo(A, 5, -12);
    construirComplejo(B, 3, 4);
    sumarComplejo(C, A, B);
    multiplicarComplejo(D, A, B);
    conjugadoComplejo(E, D);
    multiplicarComplejo(F, E, D);

    printf("%s\n",    imprimirComplejo(A));
    printf("%s\n",    imprimirComplejo(B));
    printf("%s\n",    imprimirComplejo(C));
    printf("%s\n",    imprimirComplejo(D));
    printf("%s\n",    imprimirComplejo(E));
    printf("%f\n",    moduloComplejo(E));
    printf("%f\n",    radioComplejo(E));
    printf("%f\n",    anguloComplejo(E));
    printf("%s\n",    imprimirComplejo(F));

    return 0;
}
