/*
 * ARCHIVO: complejo.c
 * DESCRIPCION: Contiene las definiciones de las primitivas del tad Complejo
 * AUTOR: Prof. Masun Nabhan Homsi
 * FECHA: 16/01/2015
 */


#include "complejo.h"
#include "triplets.h"

//*************************************************************************************
COMPLEJO construir_complejo()
/* PRE: Nada
   POST: construir_complejo devuelve un COMPLEJO con parte real x y parte imaginaria y */
{
        COMPLEJO C;

        if ((C=(COMPLEJO)malloc(sizeof(complejo)))!=NULL)
         {
            return(C);
         }
         else
            printf("No se ha podido reservar en la memoria");

}
//*************************************************************************************
void destruir_complejo (COMPLEJO r)
/* PRE: el Complejo R ha sido creado
   POST: Libera el espacio ocupado por el Complejo */
{
    _pre(r!=NULL);
    free(r);

}
//*************************************************************************************
COMPLEJO llenar_complejo(COMPLEJO C, float x, float y)
/* PRE: el Complejo C ha sido creado
   Post: devuelve un Complejo con parte real x y parte imaginaria y  */

{
    _pre(C!=NULL);
    C->preal=x;
    C->pimag=y;
    _post(C->preal==x);
    _post(C->pimag==y);
    return (C);

}
COMPLEJO sumar_complejo (COMPLEJO X, COMPLEJO Y)
/* PRE: los Complejo x, y han sido creados
   POST: Devuelve la suma */
{
    COMPLEJO C;
    C=construir_complejo();
    C->preal=(X->preal)+(Y->preal);
    C->pimag=X->pimag + Y->pimag;
    return (C);
}

char *mostrar_complejo(COMPLEJO C)
/* PRE: el COMPLEJO C ha sido creado
   POST: Devuelve el string del COMPLEJO  */
{
    char str[100]={0};
    sprintf(str, "%2.2f+%2.2fi", C->preal, C->pimag);
    printf("%s\n",str);
    return (&str[0]);


}

