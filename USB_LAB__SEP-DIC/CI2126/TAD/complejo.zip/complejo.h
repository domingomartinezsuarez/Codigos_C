/*
 * ARCHIVO: complejo.h
 * DESCRIPCION: Contiene los prototipos, pre y post condiciones de las especificaciones sintacticas del tad COMPLEJO
 * AUTOR: Prof. Masun Nabhan Homsi
 * FECHA: 16/01/2015
 */

#ifndef ncomplejo
#define ncomplejo

#include <stdio.h>
#include <stdlib.h>


typedef struct {
        float preal;
        float pimag;
} complejo;
typedef complejo *COMPLEJO;

void hi(int i);

COMPLEJO construir_complejo ();
/* PRE: Nada
   POST: construir_complejo devuelve un COMPLEJO con parte real x y parte imaginaria y */

void destruir_complejo (COMPLEJO r);
/* PRE: el COMPLEJO R ha sido creado
   POST: Libera el espacio ocupado por el COMPLEJO */

COMPLEJO llenar_complejo(COMPLEJO C, float x, float y);
/* PRE: el COMPLEJO R ha sido creado
   Post: devuelve un COMPLEJO con parte real x y parte imaginaria y  */

char *mostrar_complejo(COMPLEJO C);
/* PRE: el COMPLEJO R ha sido creado
   POST: Devuelve el string del COMPLEJO  */

float parte_real (COMPLEJO r);
/* PRE: el COMPLEJO R ha sido creado
   POST: Devuelve la parte real del COMPLEJO  */
float parte_Imag (COMPLEJO r);
/* PRE: el COMPLEJO R ha sido creado
   POST: Devuelve la parte imaginaria del COMPLEJO */

void clonar_Complejo (COMPLEJO r, COMPLEJO p);
/* PRE: p.pimag != 0
   POST: R_Crear devuelve un COMPLEJO con parte real x y parte imaginaria y */
int verificar_igualdad (COMPLEJO r, COMPLEJO p);
/* PRE: p.pimag != 0
   POST: R_Crear devuelve 1 si los dos numeros complejos son iguales y 0 si son diferentes*/

COMPLEJO sumar_complejo (COMPLEJO X, COMPLEJO Y);
/* PRE: los Complejo x, y han sido creados
   POST: Devuelve la suma */

COMPLEJO multiplicar_complejo (COMPLEJO X, COMPLEJO Y);
/* PRE: los Tomplejo x, y han sido creados
   POST: Devuelve la multiplicacion */
#endif // ncomplejo
