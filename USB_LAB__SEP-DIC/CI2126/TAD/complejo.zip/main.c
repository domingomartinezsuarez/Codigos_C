#include "triplets.h"
#include "complejo.h"

int main()
{
    COMPLEJO A, B, SUMA, D;
    char *str;
   str=(char *)malloc (100*sizeof(char));

    int i=0;


    A=construir_complejo();
    A=llenar_complejo(A, 0.1, 0.2);
    printf ("A(Real)=%f\n",A->preal);
    printf ("A(Imag)=%f\n\n",A->pimag);

    B=construir_complejo();
    B=llenar_complejo(B, 0.3, 0.6);
    printf ("B(Real)=%f\n",B->preal);
    printf ("B(Imag)=%f\n\n",B->pimag);

    SUMA=construir_complejo();
    SUMA=sumar_complejo(A, B);

    str=mostrar_complejo(SUMA);

    destruir_complejo (A);
    //destruir_complejo (D);
    printf("Hello world!\n");
    return 0;
}
